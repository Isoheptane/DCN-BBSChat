#pragma once

#include <vector>
#include <cstdint>

void packet_processor(const std::vector<uint8_t>& packet);