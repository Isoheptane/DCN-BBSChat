#include "file_pool.h"

WritingFilePool file_pool;