#pragma once
#include "FileCache.h"

extern WritingFilePool file_pool;